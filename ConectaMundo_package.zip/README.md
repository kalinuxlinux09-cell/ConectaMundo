
# ConectaMundo

Projeto pronto para deploy: frontend (Vite + React) e backend (Node.js + Express + WebSocket).
Nome do site: ConectaMundo
Idioma: Português e English (README bilingue)

## Como usar localmente

### Backend
1. Entre na pasta backend:
   ```
   cd backend
   npm install
   npm start
   ```
   O servidor rodará em http://localhost:3000 por padrão.

### Frontend
1. Entre na pasta frontend:
   ```
   cd frontend
   npm install
   npm run dev
   ```
2. Abra o link mostrado pelo Vite (ex.: http://localhost:5173).
3. Se necessário, copie `.env.example` para `.env` e ajuste `VITE_API_BASE` para apontar para seu backend.

## Deploy sugerido
- Frontend: Vercel (importar repositório)
- Backend: Render / Fly / Heroku (subir a pasta backend)
- Após deploy, ajustar `VITE_API_BASE` para apontar ao URL do backend em produção.

## Funcionalidades incluídas
- Login simulado (POST /api/auth)
- Assinatura simulada (POST /api/subscribe)
- Suporte IA simulado (POST /api/ai-support)
- Sinalização WebSocket básica para WebRTC (broadcast entre clients)

---

# English

Project ready to deploy: frontend (Vite + React) and backend (Node.js + Express + WebSocket).
Site name: ConectaMundo
Language: Portuguese and English (bilingual README)

## How to run locally

### Backend
1. Go to backend folder:
   ```
   cd backend
   npm install
   npm start
   ```
   Server will run on http://localhost:3000 by default.

### Frontend
1. Go to frontend folder:
   ```
   cd frontend
   npm install
   npm run dev
   ```
2. Open the Vite URL shown (e.g., http://localhost:5173).
3. If needed, copy `.env.example` to `.env` and set `VITE_API_BASE` to your backend URL.

## Suggested deploy
- Frontend: Vercel
- Backend: Render / Fly / Heroku
- After deployment, set `VITE_API_BASE` to backend production URL.

## Included features
- Simulated login (POST /api/auth)
- Simulated subscription (POST /api/subscribe)
- Simulated AI support (POST /api/ai-support)
- Simple WebSocket signaling for WebRTC (broadcast)
