import React, {useState} from 'react';

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:3000';

export default function App(){
  const [email,setEmail] = useState('');
  const [password,setPassword] = useState('');
  const [logged,setLogged] = useState(false);
  const [msg,setMsg] = useState('');
  const [aiReply,setAiReply] = useState('');

  async function login(e){
    e.preventDefault();
    const res = await fetch(`${API_BASE}/api/auth`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({username:email,password})
    });
    const data = await res.json();
    if(data && data.success){
      setLogged(true);
      setMsg('Login bem-sucedido');
    } else {
      setMsg('Erro no login');
    }
  }

  async function askAI(){
    if(!msg) setMsg('Envie uma pergunta no campo de IA');
    const res = await fetch(`${API_BASE}/api/ai-support`, {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({message: msg})
    });
    const data = await res.json();
    setAiReply(data.reply || 'sem resposta');
  }

  return (
    <div style={{fontFamily:'Arial, sans-serif',padding:20}}>
      <h1>ConectaMundo</h1>
      {!logged ? (
        <form onSubmit={login} style={{maxWidth:400}}>
          <div>
            <label>Email:</label><br/>
            <input value={email} onChange={e=>setEmail(e.target.value)} style={{width:'100%'}}/>
          </div>
          <div style={{marginTop:8}}>
            <label>Senha:</label><br/>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} style={{width:'100%'}}/>
          </div>
          <button style={{marginTop:12}} type="submit">Entrar</button>
        </form>
      ) : (
        <div>
          <p>Você está logado.</p>
          <button onClick={()=>setLogged(false)}>Sair</button>
        </div>
      )}

      <hr style={{margin:'20px 0'}}/>

      <section>
        <h2>Suporte IA (simulado)</h2>
        <div>
          <input value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Digite sua pergunta ou problema" style={{width:'70%'}}/>
          <button onClick={askAI} style={{marginLeft:8}}>Enviar</button>
        </div>
        {aiReply && <div style={{marginTop:12,background:'#f2f2f2',padding:10}}><strong>IA responde:</strong><div>{aiReply}</div></div>}
      </section>

      <hr style={{margin:'20px 0'}}/>

      <section>
        <h2>WebRTC / Video (Instruções)</h2>
        <p>Este pacote inclui um backend de sinalização. Para testar videochamadas em duas abas, implante backend e frontend e siga o README.</p>
      </section>
    </div>
  )
}
