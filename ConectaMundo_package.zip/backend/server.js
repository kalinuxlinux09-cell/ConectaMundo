const express = require('express');
const http = require('http');
const { WebSocketServer } = require('ws');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

// Simple mock auth
app.post('/api/auth', (req, res) => {
  const { username, password } = req.body;
  if(username && password){
    return res.json({ success: true, token: 'fake-jwt-token', user: { id: 'u1', name: username, isPremium: false } });
  }
  return res.status(400).json({ success: false, error: 'missing' });
});

// Mock subscribe
app.post('/api/subscribe', (req, res) => {
  return res.json({ success: true, plan: 'premium' });
});

// Mock AI support
app.post('/api/ai-support', (req, res) => {
  const { message } = req.body;
  const reply = `🤖 IA: Recebi sua mensagem — "${message}". Aqui está uma resposta simulada.`;
  return res.json({ reply });
});

// Signaling (simple broadcast)
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
let clients = [];
wss.on('connection', (ws) => {
  clients.push(ws);
  ws.on('message', (msg) => {
    // Broadcast to others
    clients.forEach(c => {
      if(c !== ws && c.readyState === 1) c.send(msg);
    });
  });
  ws.on('close', () => {
    clients = clients.filter(c => c !== ws);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log(`ConectaMundo backend rodando em http://localhost:${PORT}`));
